import type { MetadataRoute } from "next";

export default function robots() 
{
  return {
    rules: {
      userAgent: "*",
      allow: "/",
    },
    sitemap: "https://www.blacktierexecutive.com/sitemap.xml",
  };
}