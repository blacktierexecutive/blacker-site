export const CONTACT = {
  phoneDisplay: "(000) 000-0000",
  phoneHref: "tel:0000000000",
  email: "info@blacktierexecutive.com",
  emailHref: "mailto:info@blacktierexecutive.com",
};
